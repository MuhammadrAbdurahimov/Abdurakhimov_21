package com.example.a21_yusupov_abdurahimov

import android.R
import android.content.ContentValues
import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity


class UserActivity() : AppCompatActivity() {
    var nameBox: EditText? = null
    var yearBox: EditText? = null
    var delButton: Button? = null
    var saveButton: Button? = null

    var sqlHelper: DatabaseHelper? = null
    var db: SQLiteDatabase? = null
    var userCursor: Cursor? = null
    var userId: Long = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user)

        nameBox = findViewById<EditText>(R.id.name)
        yearBox = findViewById<EditText>(R.id.year)
        delButton = findViewById<Button>(R.id.deleteButton)
        saveButton = findViewById<Button>(R.id.saveButton)

        sqlHelper = DatabaseHelper(this)
        db = sqlHelper!!.writableDatabase

        val extras = intent.extras
        if (extras != null) {
            userId = extras.getLong("id")
        }
        // если 0, то добавление
        if (userId > 0) {
            // получаем элемент по id из бд
            userCursor = db.rawQuery(
                "select * from " + DatabaseHelper.TABLE + " where " +
                        DatabaseHelper.COLUMN_ID + "=?", arrayOf(userId.toString())
            )
            userCursor.moveToFirst()
            nameBox.setText(userCursor.getString(1))
            yearBox.setText(userCursor.getInt(2).toString())
            userCursor.close()
        } else {
            // скрываем кнопку удаления
            delButton.setVisibility(View.GONE)
        }
    }

    fun save(view: View?) {
        val cv = ContentValues()
        cv.put(DatabaseHelper.COLUMN_NAME, nameBox!!.text.toString())
        cv.put(DatabaseHelper.COLUMN_YEAR, yearBox!!.text.toString().toInt())

        if (userId > 0) {
            db!!.update(DatabaseHelper.TABLE, cv, DatabaseHelper.COLUMN_ID + "=" + userId, null)
        } else {
            db!!.insert(DatabaseHelper.TABLE, null, cv)
        }
        goHome()
    }

    fun delete(view: View?) {
        db!!.delete(DatabaseHelper.TABLE, "_id = ?", arrayOf(userId.toString()))
        goHome()
    }

    private fun goHome() {
        // закрываем подключение
        db!!.close()
        // переход к главной activity
        val intent = Intent(
            this,
            MainActivity::class.java
        )
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        startActivity(intent)
    }

    Bundle extras = getIntent().getExtras();
    if (extras != null) {
        val extras = null.also {
            userId = it.getLong("id")
        }
        if (id < 0) {

            userCursor = db.rawQuery("select * from " + DatabaseHelper.TABLE + " where " +
                    DatabaseHelper.COLUMN_ID + "=?", new String[]{String.valueOf(id)});
            userCursor.moveToFirst();
            nameBox.setText(userCursor.getString(1));
            yearBox.setText(String.valueOf(userCursor.getInt(2)));
            userCursor.close();
        }

        db.delete(DatabaseHelper.TABLE, "_id = ?", new String[]{String.valueOf(id)});

        val cv = ContentValues()
        cv.put("NAME", "Tom")
        cv.put("YEAR", 30)
        ContentValues cv = new ContentValues();
        cv.put(DatabaseHelper.COLUMN_NAME, nameBox.getText().toString());
        cv.put(DatabaseHelper.COLUMN_YEAR, Integer.parseInt(yearBox.getText().toString()));

        val cv = ContentValues()
        cv.put(DatabaseHelper.COLUMN_NAME, nameBox!!.text.toString())
        cv.put(DatabaseHelper.COLUMN_YEAR, yearBox!!.text.toString().toInt())

        db.update(DatabaseHelper.TABLE, cv, DatabaseHelper.COLUMN_ID + "=" + userId, null);
        db.insert(DatabaseHelper.TABLE, null, cv);
        long result = db.insert(DatabaseHelper.TABLE, null, cv);
        if(result>0) {
        }
    }

