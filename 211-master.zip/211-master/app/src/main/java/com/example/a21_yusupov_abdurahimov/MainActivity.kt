package com.example.a21_yusupov_abdurahimov

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import java.lang.reflect.Modifier


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val viewModel = viewModel<MainViewModel>()
            UserInputScreen(viewModel = viewModel)
        }
    }
}

@Composable
fun UserInputScreen(viewModel: MainViewModel) {
    var name by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Name") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = year,
            onValueChange = { year = it },
            label = { Text("Year") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = {
            viewModel.saveUser(name, year.toIntOrNull() ?: 0)
        }) {
            Text("Save")
        }
    }
}
class DatabaseHelper(context: Context?) :
    SQLiteOpenHelper(context, magazin, null, SCHEMA) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE users (" + COLUMN_ID
                    + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_NAME
                    + " TEXT, " + COLUMN_YEAR + " INTEGER);"
        )
        // добавление начальных данных
        db.execSQL(
            ("INSERT INTO " + TABLE + " (" + COLUMN_NAME
                    + ", " + COLUMN_YEAR + ") VALUES ('Том Смит', 1981);")
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE)
        onCreate(db)
    }

    companion object {
        private val DATABASE_NAME = "magazin.db" // название бд
        private val SCHEMA = 1 // версия базы данных
        val TABLE: String = "users" // название таблицы в бд

        // названия столбцов
        val COLUMN_ID: String = "_id"
        val COLUMN_NAME: String = "name"
        val COLUMN_YEAR: String = "year"
    }
}
